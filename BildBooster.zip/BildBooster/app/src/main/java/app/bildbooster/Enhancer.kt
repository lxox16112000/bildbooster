package app.bildbooster

import android.graphics.Bitmap
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

data class Settings(
    val upscale: Boolean = true,
    val whiteBalance: Boolean = true,
    val hdr: Float = 0.5f,
    val color: Float = 0.5f,
    val sharpen: Float = 0.5f,
)

private fun ByteArray.u(i: Int) = this[i].toInt() and 255

private fun luma(p: Int) =
    0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)

object Enhancer {
    private const val MAX_OUT = 3072 // max. lange Kante des Ergebnisses (Speicherschutz für ältere Geräte)

    fun process(src: Bitmap, s: Settings, up: Upscaler, progress: (Float, String) -> Unit): Bitmap {
        var bmp = src
        var scaled = false
        if (s.upscale) {
            val sc = if (up.hasModel) up.scale else 2
            val f = MAX_OUT.toFloat() / (max(bmp.width, bmp.height) * sc)
            if (f < 1f) {
                bmp = Bitmap.createScaledBitmap(
                    bmp, max(1, (bmp.width * f).toInt()), max(1, (bmp.height * f).toInt()), true
                )
            }
            bmp = up.upscale(bmp) { progress(it * 0.8f, "Hochskalieren …") }
            scaled = true
        }
        progress(0.85f, "HDR, Farben, Schärfe …")
        val out = if (bmp !== src && bmp.isMutable && bmp.config == Bitmap.Config.ARGB_8888) bmp
        else bmp.copy(Bitmap.Config.ARGB_8888, true)
        tone(out, s, scaled)
        progress(1f, "Fertig")
        return out
    }

    private fun tone(bmp: Bitmap, s: Settings, scaled: Boolean) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        // 1) Weißabgleich (Gray-World, begrenzt)
        var gr = 1f
        var gg = 1f
        var gb = 1f
        if (s.whiteBalance) {
            var sr = 0L; var sg = 0L; var sb = 0L; var n = 0L
            var i = 0
            while (i < px.size) {
                val p = px[i]
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
                n++
                i += 11
            }
            val mr = max(sr.toFloat() / n, 1f)
            val mg = max(sg.toFloat() / n, 1f)
            val mb = max(sb.toFloat() / n, 1f)
            val m = (mr + mg + mb) / 3f
            gr = (m / mr).coerceIn(0.8f, 1.25f)
            gg = (m / mg).coerceIn(0.8f, 1.25f)
            gb = (m / mb).coerceIn(0.8f, 1.25f)
        }

        // 2) Grobe Helligkeitskarte (1/16 Auflösung) für lokales Tone-Mapping
        val sw = max(2, w / 16)
        val sh = max(2, h / 16)
        val sp = IntArray(sw * sh)
        Bitmap.createScaledBitmap(bmp, sw, sh, true).getPixels(sp, 0, sw, 0, 0, sw, sh)
        val base = FloatArray(sw * sh) { luma(sp[it]) / 255f }

        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val fx = FloatArray(w)
        for (x in 0 until w) {
            val f = (x + 0.5f) * sw / w - 0.5f
            val a = floor(f).toInt()
            x0[x] = a.coerceIn(0, sw - 1)
            x1[x] = (a + 1).coerceIn(0, sw - 1)
            fx[x] = (f - a).coerceIn(0f, 1f)
        }

        val lum = ByteArray(w * h)
        val e = s.hdr * 0.35f
        val vib = s.color * 0.8f

        for (y in 0 until h) {
            val f = (y + 0.5f) * sh / h - 0.5f
            val a = floor(f).toInt()
            val r0 = a.coerceIn(0, sh - 1) * sw
            val r1 = (a + 1).coerceIn(0, sh - 1) * sw
            val ty = (f - a).coerceIn(0f, 1f)
            for (x in 0 until w) {
                val top = base[r0 + x0[x]] * (1 - fx[x]) + base[r0 + x1[x]] * fx[x]
                val bot = base[r1 + x0[x]] * (1 - fx[x]) + base[r1 + x1[x]] * fx[x]
                val bl = top * (1 - ty) + bot * ty
                // Dunkle Bereiche aufhellen, helle abdunkeln (Detail bleibt durch multiplikative Anwendung erhalten)
                val gain = if (e > 0f) (0.45f / (bl + 0.03f)).pow(e).coerceIn(0.7f, 2.2f) else 1f

                val i = y * w + x
                val p = px[i]
                var r = ((p shr 16) and 255) * gr * gain
                var g = ((p shr 8) and 255) * gg * gain
                var b = (p and 255) * gb * gain

                // 3) Vibrance: wenig gesättigte Farben stärker anheben
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                val sat = if (mx > 1f) (mx - mn) / mx else 0f
                val k = 1f + vib * (1f - sat)
                r = l + (r - l) * k
                g = l + (g - l) * k
                b = l + (b - l) * k

                val ri = r.toInt().coerceIn(0, 255)
                val gi = g.toInt().coerceIn(0, 255)
                val bi = b.toInt().coerceIn(0, 255)
                px[i] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
                lum[i] = (0.299f * ri + 0.587f * gi + 0.114f * bi).toInt().toByte()
            }
        }

        // 4) Schärfen: Unsharp Mask nur auf der Helligkeit (keine Farbsäume)
        if (s.sharpen > 0f) {
            val rad = if (scaled) 2 else 1
            val amt = s.sharpen * 1.5f
            for (y in rad until h - rad) {
                var i = y * w + rad
                for (x in rad until w - rad) {
                    val c = lum.u(i)
                    val blur = (4 * c +
                        2 * (lum.u(i - rad) + lum.u(i + rad) + lum.u(i - rad * w) + lum.u(i + rad * w)) +
                        lum.u(i - rad - rad * w) + lum.u(i + rad - rad * w) +
                        lum.u(i - rad + rad * w) + lum.u(i + rad + rad * w)) / 16f
                    val d = (c - blur) * amt
                    if (d > 0.5f || d < -0.5f) {
                        val p = px[i]
                        val ri = (((p shr 16) and 255) + d).toInt().coerceIn(0, 255)
                        val gi = (((p shr 8) and 255) + d).toInt().coerceIn(0, 255)
                        val bi = ((p and 255) + d).toInt().coerceIn(0, 255)
                        px[i] = (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
                    }
                    i++
                }
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }
}
