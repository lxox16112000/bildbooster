package app.bildbooster

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } } }
    }
}

/** Verkleinerte Anzeigeversion, damit große Bitmaps die GPU-Texturgrenze nicht sprengen. */
private fun Bitmap.preview(max: Int = 1600): Bitmap {
    val f = max.toFloat() / maxOf(width, height)
    return if (f >= 1f) this
    else Bitmap.createScaledBitmap(this, (width * f).toInt(), (height * f).toInt(), true)
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val upscaler = remember { Upscaler(ctx) }
    DisposableEffect(Unit) { onDispose { upscaler.close() } }

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var showOriginal by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember {
        mutableStateOf(if (upscaler.hasModel) "KI-Modell geladen" else "Kein Modell gefunden – es wird normal skaliert")
    }
    var upscale by remember { mutableStateOf(true) }
    var wb by remember { mutableStateOf(true) }
    var hdr by remember { mutableFloatStateOf(0.5f) }
    var color by remember { mutableFloatStateOf(0.5f) }
    var sharp by remember { mutableFloatStateOf(0.5f) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            status = "Lade Bild …"
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(ctx, uri) }
            original = bmp
            result = null
            status = if (bmp == null) "Bild konnte nicht geladen werden" else "Bereit: ${bmp.width}×${bmp.height}"
        }
    }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        val bmp = result
        if (uri != null && bmp != null) scope.launch(Dispatchers.IO) {
            ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            status = "Gespeichert"
        }
    }

    val shown = remember(original, result, showOriginal) {
        (if (showOriginal) original else (result ?: original))?.preview()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Bild-Booster", style = MaterialTheme.typography.headlineSmall)
        shown?.let {
            Image(
                it.asImageBitmap(), null,
                Modifier.fillMaxWidth().heightIn(max = 340.dp),
                contentScale = ContentScale.Fit
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = !busy
            ) { Text("Bild wählen") }
            Button(
                enabled = original != null && !busy,
                onClick = {
                    val src = original ?: return@Button
                    busy = true
                    progress = 0f
                    scope.launch {
                        val cfg = Settings(upscale, wb, hdr, color, sharp)
                        val res = withContext(Dispatchers.Default) {
                            runCatching {
                                Enhancer.process(src, cfg, upscaler) { p, t -> progress = p; status = t }
                            }
                        }
                        res.onSuccess { result = it; showOriginal = false; status = "Fertig: ${it.width}×${it.height}" }
                            .onFailure { status = "Fehler: ${it.message ?: it.javaClass.simpleName}" }
                        busy = false
                    }
                }
            ) { Text("Verbessern") }
        }

        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        Text(status, style = MaterialTheme.typography.bodySmall)

        Toggle("KI-Hochskalieren", upscale) { upscale = it }
        Toggle("Automatischer Weißabgleich", wb) { wb = it }
        Labeled("HDR", hdr) { hdr = it }
        Labeled("Farben", color) { color = it }
        Labeled("Schärfe", sharp) { sharp = it }

        if (result != null) {
            Toggle("Original zeigen", showOriginal) { showOriginal = it }
            Button(onClick = { save.launch("verbessert.jpg") }, enabled = !busy) { Text("Speichern") }
        }
    }
}

@Composable
private fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(checked, onChange)
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}

@Composable
private fun Labeled(label: String, value: Float, onChange: (Float) -> Unit) {
    Column {
        Text("$label: ${(value * 100).toInt()} %", style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onChange)
    }
}
