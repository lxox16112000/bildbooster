package app.bildbooster

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Lädt assets/upscaler.tflite (NHWC, float32) und skaliert Bilder kachelweise hoch.
 * Kachelgröße und Faktor werden aus dem Modell gelesen. Ohne Modell: normale 2x-Skalierung.
 */
class Upscaler(context: Context) : AutoCloseable {

    private val interp: Interpreter? = try {
        val bytes = context.assets.open(MODEL).use { it.readBytes() }
        val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buf.put(bytes)
        buf.rewind()
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        Interpreter(buf, Interpreter.Options().setNumThreads(threads))
    } catch (e: Exception) {
        null
    }

    val hasModel: Boolean get() = interp != null
    private var tile = 0
    var scale = 2
        private set

    init {
        interp?.let {
            tile = it.getInputTensor(0).shape()[1]
            if (tile < 16) { // dynamische Eingabe -> feste Kachel wählen
                tile = 128
                it.resizeInput(0, intArrayOf(1, tile, tile, 3))
                it.allocateTensors()
            }
            scale = (it.getOutputTensor(0).shape()[1] / tile).coerceAtLeast(1)
        }
    }

    fun upscale(src: Bitmap, progress: (Float) -> Unit): Bitmap {
        val ip = interp
            ?: return Bitmap.createScaledBitmap(src, src.width * 2, src.height * 2, true)

        val w = src.width
        val h = src.height
        val s = scale
        val t = tile
        val o = minOf(OVERLAP, (t - 1) / 4)
        val step = t - 2 * o
        val ts = t * s

        val inPx = IntArray(w * h)
        src.getPixels(inPx, 0, w, 0, 0, w, h)
        val out = Bitmap.createBitmap(w * s, h * s, Bitmap.Config.ARGB_8888)

        val inBuf = ByteBuffer.allocateDirect(t * t * 3 * 4).order(ByteOrder.nativeOrder())
        val outBuf = ByteBuffer.allocateDirect(ts * ts * 3 * 4).order(ByteOrder.nativeOrder())
        val fin = inBuf.asFloatBuffer()
        val fout = outBuf.asFloatBuffer()
        val kIn = if (INPUT_0_255) 1f else 1f / 255f
        val kOut = if (INPUT_0_255) 1f else 255f

        val total = ((w + step - 1) / step) * ((h + step - 1) / step)
        var done = 0
        var ty = 0
        while (ty < h) {
            var tx = 0
            while (tx < w) {
                // Kachel mit Überlappung füllen (Ränder werden gespiegelt/geklemmt)
                fin.rewind()
                for (y in 0 until t) {
                    val sy = (ty - o + y).coerceIn(0, h - 1)
                    for (x in 0 until t) {
                        val p = inPx[sy * w + (tx - o + x).coerceIn(0, w - 1)]
                        fin.put(((p shr 16) and 255) * kIn)
                        fin.put(((p shr 8) and 255) * kIn)
                        fin.put((p and 255) * kIn)
                    }
                }
                ip.run(inBuf, outBuf)

                // Nur den Kern der Kachel übernehmen
                val cw = minOf(step, w - tx)
                val ch = minOf(step, h - ty)
                val blk = IntArray(cw * s * ch * s)
                for (oy in 0 until ch * s) {
                    val rowBase = (o * s + oy) * ts
                    for (ox in 0 until cw * s) {
                        val i = (rowBase + o * s + ox) * 3
                        val r = (fout.get(i) * kOut).toInt().coerceIn(0, 255)
                        val g = (fout.get(i + 1) * kOut).toInt().coerceIn(0, 255)
                        val b = (fout.get(i + 2) * kOut).toInt().coerceIn(0, 255)
                        blk[oy * cw * s + ox] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                out.setPixels(blk, 0, cw * s, tx * s, ty * s, cw * s, ch * s)
                done++
                progress(done / total.toFloat())
                tx += step
            }
            ty += step
        }
        return out
    }

    override fun close() {
        interp?.close()
    }

    companion object {
        const val MODEL = "upscaler.tflite"
        const val OVERLAP = 8
        const val INPUT_0_255 = false // true, falls das Modell Werte 0..255 erwartet
    }
}
