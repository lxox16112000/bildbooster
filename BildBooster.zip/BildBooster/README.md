# Bild-Booster

Android-App: Bilder lokal verbessern (KI-Hochskalieren, HDR, Farben, Schärfen). Kein Cloud-Upload.

## APK bauen
1. Ordner in Android Studio öffnen (Gradle-Sync abwarten).
2. Build > Build Bundle(s) / APK(s) > Build APK(s).

## KI-Modell
- Datei als `app/src/main/assets/upscaler.tflite` ablegen.
- Eingabe/Ausgabe: `[1, H, W, 3]` float32. Kachelgröße und Skalierungsfaktor werden aus dem Modell gelesen.
- Erwartet das Modell Werte 0..255 statt 0..1, in `Upscaler.kt` `INPUT_0_255 = true` setzen.

## Pipeline
Hochskalieren (Kacheln mit Überlappung) > Weißabgleich > lokales Tone-Mapping (HDR-Look) > Vibrance > Unsharp Mask auf der Helligkeit.
